package com.example.evolvu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvolvuApplicationTests {

	@Test
	void contextLoads() {
	}

}
