package com.example.evolvu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvolvuApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvolvuApplication.class, args);
	}

}
